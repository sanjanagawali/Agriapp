package com.secson.agriapp.constants;

/**
 * Created by Ankita on 17/09/2018.
 */

public interface IConstatnts {

    String isLoggedin = "isLoggedin";
    String userName = "name";
    String pass = "pass";
    String number = "number";
    String email = "email";

}
