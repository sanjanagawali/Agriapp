package com.secson.agriapp.utils;

import android.content.Context;
import android.content.SharedPreferences;



public class AgriappSharedPreference {

    Context context;
    SharedPreferences agriPref;
    SharedPreferences.Editor agriEditor;

    //    get
    public void set(Context context,String key,String value){

        agriPref=context.getSharedPreferences("agriPref",Context.MODE_PRIVATE);
        agriEditor=agriPref.edit();
        agriEditor.putString(key,value);

        agriEditor.commit();
    }

    public String get(Context context,String key){
        agriPref=context.getSharedPreferences("agriPref",Context.MODE_PRIVATE);
        return agriPref.getString(key,"");
    }

    public boolean contains(Context context,String key){
        agriPref=context.getSharedPreferences("agriPref",Context.MODE_PRIVATE);
        return agriPref.contains(key);
    }

    public void clear(Context context){
        agriPref=context.getSharedPreferences("agriPref",Context.MODE_PRIVATE);
        agriEditor=agriPref.edit();
        agriEditor.clear();
        agriEditor.commit();
    }



}
