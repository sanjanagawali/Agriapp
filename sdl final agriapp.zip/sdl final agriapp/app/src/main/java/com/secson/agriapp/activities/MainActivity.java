package com.secson.agriapp.activities;

import android.app.Dialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.secson.agriapp.R;
import com.secson.agriapp.adapter.Drawer_Menu_Adapter;
import com.secson.agriapp.constants.IConstatnts;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.fonts.tt0144m;
import com.secson.agriapp.fragment.AskFragment;
import com.secson.agriapp.fragment.FertilizersFragment;
import com.secson.agriapp.model.User;
import com.secson.agriapp.utils.AgriappSharedPreference;
import com.secson.agriapp.utils.CircularImageView;
import com.secson.agriapp.utils.DBManager;
import com.secson.agriapp.utils.DatabaseHelper;
import com.secson.agriapp.utils.ExportDatabase;
import com.secson.agriapp.utils.AgriappSharedPreference;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {
    Toolbar toolbar;
    ListView menu_list;
    Drawer_Menu_Adapter adapter;
    ArrayList<String> MenuItems;
    ArrayList<String> MenuCount;
    ArrayList<Integer> MenuIcon;
    DrawerLayout drawer;
    AgriappSharedPreference sp;
    FragmentTransaction tx;
    CircularImageView ivProfilePicture;
    tt0144m tvFullName, home;
    Dialog dialog;
    tt0142m dialogBtnOk, dialogBtnCancel;
    String annCount, forumCount;
    ImageView ivLogo, ivIcon;
    tt0144m tvTitle;

    private DBManager dbManager;
    ArrayList<User>usetList;
    tt0144m tvLogo;
    //ivLogo
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        DatabaseHelper _dbHelper = new DatabaseHelper(MainActivity.this);
        SQLiteDatabase db = _dbHelper.getWritableDatabase();

        ExportDatabase exportDatabase = new ExportDatabase(MainActivity.this);
        exportDatabase.execute();

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        menu_list = (ListView) findViewById(R.id.menu_list);
        ivProfilePicture = (CircularImageView) findViewById(R.id.ivProfilePicture);
        tvFullName = (tt0144m) findViewById(R.id.tvFullName);
        tvLogo =  toolbar.findViewById(R.id.ivLogo);

        //Dialog Signout
        dialog = new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_signout);
        dialogBtnOk = (tt0142m) dialog.findViewById(R.id.submitBtnBox2);
        dialogBtnCancel = (tt0142m) dialog.findViewById(R.id.cancelBtnBox2);

        ivProfilePicture.setOnClickListener(this);
        dbManager = new DBManager(this);
        dbManager.open();
        sp = new AgriappSharedPreference();

        /*final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                setupNavigationDrawer();
            }
        }, 2000);*/

        usetList = dbManager.getUserObject(sp.get(MainActivity.this, IConstatnts.number));

        String username = usetList.get(0).getName();
        tvFullName.setText(username);
        setupNavigationDrawer();

        FertilizersFragment fertilizersFragment = new FertilizersFragment();
        Bundle bundle = new Bundle();
        bundle.putString("Type", "fertilizer");
        fertilizersFragment.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_container, fertilizersFragment)
                .commit();

    }
    public void setupNavigationDrawer() {

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.setDrawerIndicatorEnabled(false);
        toolbar.setNavigationIcon(R.drawable.drawer_icon);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.openDrawer(GravityCompat.START);
            }
        });


        MenuItems = new ArrayList<>();

        MenuItems.add("Fertilizers");
        MenuItems.add("Seeds");
        MenuItems.add("Tools");
        MenuItems.add("Ask Experts");
        MenuItems.add("Share");
        MenuItems.add("Signout");

        MenuIcon = new ArrayList<>();

        MenuIcon.add(R.drawable.icon_marketingresource);
        MenuIcon.add(R.drawable.icon_marketingresource);
        MenuIcon.add(R.drawable.icon_marketingresource);
        MenuIcon.add(R.drawable.icon_ask);
        MenuIcon.add(R.drawable.icon_share);
        MenuIcon.add(R.drawable.icon_signout);

        MenuCount = new ArrayList<>();

        MenuCount.add("");
        MenuCount.add("");
        MenuCount.add("");
        MenuCount.add("");
        MenuCount.add("");
        MenuCount.add("");


        adapter = new Drawer_Menu_Adapter(MainActivity.this, MenuItems, MenuIcon, MenuCount);
        menu_list.setAdapter(adapter);

        menu_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                drawer.closeDrawer(GravityCompat.START);
                switch (position) {
                    case 0:
                        FertilizersFragment productmarketing = new FertilizersFragment();
                        Bundle bundle = new Bundle();
                        bundle.putString("Type", "fertilizer");
                        productmarketing.setArguments(bundle);
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.frame_container, productmarketing)
                                .addToBackStack(null)
                                .commit();
                        break;

                    case 1:
                        FertilizersFragment seeds = new FertilizersFragment();
                        Bundle bundle1 = new Bundle();
                        bundle1.putString("Type", "seeds");
                        seeds.setArguments(bundle1);
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.frame_container, seeds)
                                .addToBackStack(null)
                                .commit();
                        break;
                    case 2:
                        FertilizersFragment tools = new FertilizersFragment();
                        Bundle bundle2 = new Bundle();
                        bundle2.putString("Type", "tools");
                        tools.setArguments(bundle2);
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.frame_container, tools)
                                .addToBackStack(null)
                                .commit();
                        break;

                    case 3:
                        AskFragment ask = new AskFragment();
                        Bundle bundle3 = new Bundle();
                        bundle3.putString("Type", "ask");
                        ask.setArguments(bundle3);
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.frame_container, ask)
                                .addToBackStack(null)
                                .commit();
                        break;

                    case 4:
                        //Toast.makeText(MainActivity.this, "Share app", Toast.LENGTH_SHORT).show();
                        share();
                        break;

                    case 5:
                        dialogBtnOk.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                sp.clear(MainActivity.this);

                                Intent loginactivity = new Intent(MainActivity.this, LoginActivity.class);
                                loginactivity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                loginactivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                loginactivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                loginactivity.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                startActivity(loginactivity);

                                dialog.dismiss();
                            }
                        });

                        dialogBtnCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        dialog.show();
                        break;

                }
            }
        });


    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
           /* super.onBackPressed();
            finish();*/
        }
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivProfilePicture:
            case R.id.tvFullName:
                Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
                startActivity(intent);
                drawer.closeDrawer(GravityCompat.START);
                break;
        }
    }


    private void share(){
        String mText;
        //String url = "https://play.google.com/store/apps/details?id=com.g5web.carecylinder&referrer=";
        //String url = "https://play.google.com/store/apps/details?id=com.g5web.carecylinder&referrer="+"utm_source%3D"+AAP_NAME+"%26utm_medium%3D"+"medium"+"%26utm_campaign%3D"+"campaign"+"%26utm_content%3D"+sp.get(PeopleUnderMeActivity_Demo.this, Constants.UserCode);

        //Toast.makeText(this, mLangDis, Toast.LENGTH_SHORT).show();

            mText = "Check out on'Agriapp',I use it to purchase agricultural products according to our requirements,checkout price and do payment.Get it for free at https://agriapp.com/dl/  ";
            Intent emailIntent = new Intent();
        emailIntent.setAction(Intent.ACTION_SEND);
        // Native email client doesn't currently support HTML, but it doesn't hurt to try in case they fix it
        emailIntent.putExtra(Intent.EXTRA_TEXT, mText);
        //emailIntent.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.share_email_subject));
        emailIntent.setType("message/rfc822");
        PackageManager pm = getPackageManager();
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");

        Intent openInChooser = Intent.createChooser(emailIntent, getString(R.string.share_with));

        List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);
        List<LabeledIntent> intentList = new ArrayList<>();

        for (int i = 0; i < resInfo.size(); i++) {
            // Extract the label, append it, and repackage it in a LabeledIntent
            ResolveInfo ri = resInfo.get(i);
            String packageName = ri.activityInfo.packageName;
            if (packageName.contains("android.email")) {
                emailIntent.setPackage(packageName);
            } else if (/* packageName.contains("android.gm") || */packageName.contains("whatsapp") || packageName.contains("mms")) {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(packageName, ri.activityInfo.name));
                intent.setAction(Intent.ACTION_SEND);
                intent.setType("text/plain");
                /*if(packageName.contains("android.gm")) { // If Gmail shows up twice, try removing this else-if clause and the reference to "android.gm" above
                    intent.putExtra(Intent.EXTRA_TEXT, text);
                    //intent.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.share_email_subject));
                    intent.setType("message/rfc822");
                }else*/
                if (packageName.contains("whatsapp")) {
                    intent.putExtra(Intent.EXTRA_TEXT, mText);
                } else if (packageName.contains("mms")) {
                    intent.putExtra(Intent.EXTRA_TEXT, mText);
                }
                intentList.add(new LabeledIntent(intent, packageName, ri.loadLabel(pm), ri.icon));
            }
        }
        // convert intentList to array
        LabeledIntent[] extraIntents = intentList.toArray(new LabeledIntent[intentList.size()]);

        openInChooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents);
        startActivity(openInChooser);
    }

}
