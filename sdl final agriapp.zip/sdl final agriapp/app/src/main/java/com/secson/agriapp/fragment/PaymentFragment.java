package com.secson.agriapp.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.secson.agriapp.R;
import com.secson.agriapp.activities.Paymentact;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.fonts.tt0144m;


public class PaymentFragment extends Fragment {
    private Context mContext;
    String imgName;
    String rs;
    int img;
    ImageView imgProduct;
    tt0144m imgTitle;
    tt0142m txtRs, txtCheckTo;
    LinearLayout llCheckout;
    Dialog dialog;
    tt0142m dialogBtnOk, dialogBtnCancel;
    Toolbar toolbar;
    tt0144m tvToolbarTitle;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            imgName = bundle.getString("title");
            rs = bundle.getString("rs");
            img = bundle.getInt("img");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragmet_payment, container, false);
        mContext = getActivity();
        toolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        imgProduct = v.findViewById(R.id.imgPrduct);
        imgTitle = v.findViewById(R.id.txtTitle);
        txtRs = v.findViewById(R.id.txtTotalRs);
        txtCheckTo = v.findViewById(R.id.txtTotal);
        llCheckout = v.findViewById(R.id.llCheckout);

        dialog = new Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_event);
        dialogBtnOk = (tt0142m) dialog.findViewById(R.id.tvOk);
        dialogBtnCancel = (tt0142m) dialog.findViewById(R.id.tvCancel);
        tvToolbarTitle =  toolbar.findViewById(R.id.ivLogo);

        imgProduct.setImageResource(img);
        imgTitle.setText(imgName);
        txtRs.setText(mContext.getResources().getString(R.string.Rs) + " " + rs);
        txtCheckTo.setText(mContext.getResources().getString(R.string.Rs) + " " + rs);

        tvToolbarTitle.setText("Payment");

        llCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(mContext, "Payment Successfull", Toast.LENGTH_SHORT).show();
               /* dialogBtnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(mContext, "Payment Successfull", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });

                dialogBtnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();*/

                Intent intent=new Intent(getActivity(),Paymentact.class);
                getActivity().startActivity(intent);

            }
        });
        return v;
    }

}
