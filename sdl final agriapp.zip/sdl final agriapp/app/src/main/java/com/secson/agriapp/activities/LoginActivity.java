package com.secson.agriapp.activities;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.secson.agriapp.R;
import com.secson.agriapp.constants.IConstatnts;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.utils.DBManager;
import com.secson.agriapp.utils.DatabaseHelper;
import com.secson.agriapp.utils.AgriappSharedPreference;

public class LoginActivity extends AppCompatActivity {
    tt0142m txtRegister, tvLogin;

    EditText etNumber, etPass;
    private DBManager dbManager;
    Cursor cursor;
    String pass;
    AgriappSharedPreference sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtRegister = findViewById(R.id.txtRegister);
        tvLogin = findViewById(R.id.tvLogin);
        etNumber = findViewById(R.id.etNumber);
        etPass = findViewById(R.id.etPassword);

        dbManager = new DBManager(this);
        dbManager.open();
        sp = new AgriappSharedPreference();

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (!etNumber.getText().toString().isEmpty()) {
                    pass = dbManager.getUser(etNumber.getText().toString().trim());
                }


                if (etNumber.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter the number.", Toast.LENGTH_SHORT).show();
                } else if (etPass.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter the Password.", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equalsIgnoreCase("") || pass == "") {
                        Toast.makeText(LoginActivity.this, "Invalid login credential.", Toast.LENGTH_SHORT).show();

                    } else if (pass.equalsIgnoreCase(etPass.getText().toString().trim())) {

                        Toast.makeText(LoginActivity.this, "Successful login", Toast.LENGTH_SHORT).show();
                        sp.set(LoginActivity.this, IConstatnts.isLoggedin, "true");
                        sp.set(LoginActivity.this, IConstatnts.number, etNumber.getText().toString().trim());
                        Intent loginactivity = new Intent(LoginActivity.this, MainActivity.class);
                        loginactivity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        loginactivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        loginactivity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        loginactivity.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(loginactivity);
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid login credential.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        txtRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
