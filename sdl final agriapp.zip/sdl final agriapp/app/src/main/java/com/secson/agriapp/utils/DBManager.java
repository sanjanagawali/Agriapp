package com.secson.agriapp.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.secson.agriapp.model.User;

import java.util.ArrayList;

public class DBManager {

    private DatabaseHelper dbHelper;

    private Context context;

    private SQLiteDatabase database;
    ArrayList<User> userList;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(String name, String number, String email, String address ,String password) {
        Log.i("databse", ":   inserted");
        //Toast.makeText(context, "Data inserted", Toast.LENGTH_SHORT).show();
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.NAME, name);
        contentValue.put(DatabaseHelper.NUMBER, number);
        contentValue.put(DatabaseHelper.EMAIL, email);
        contentValue.put(DatabaseHelper.ADDRESS,address);
        contentValue.put(DatabaseHelper.PASSWORD, password);
        database.insert(DatabaseHelper.TABLE_NAME, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[]{DatabaseHelper._ID, DatabaseHelper.NAME, DatabaseHelper.NUMBER, DatabaseHelper.EMAIL,DatabaseHelper.ADDRESS, DatabaseHelper.PASSWORD};
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public String getUser(String number) {


        String password = "";
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from USERS where number =" + number, null);
        cursor.moveToFirst();

        while (cursor.isAfterLast() == false) {
            password = cursor.getString(cursor.getColumnIndex("pass"));
            cursor.moveToNext();
        }

        return password;


    }
    public ArrayList<User> getUserObject(String number) {


        userList = new ArrayList<>();
        User user = new User();
        String name = "";
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from USERS where number =" + number, null);
        cursor.moveToFirst();

        while (cursor.isAfterLast() == false) {
            name = cursor.getString(cursor.getColumnIndex("name"));
            user.setName(cursor.getString(cursor.getColumnIndex("name")));
            user.setNumber(cursor.getString(cursor.getColumnIndex("number")));
            user.setEmail(cursor.getString(cursor.getColumnIndex("email")));
            user.setAddress(cursor.getString(cursor.getColumnIndex("address")));
            user.setPassword(cursor.getString(cursor.getColumnIndex("pass")));
            cursor.moveToNext();
        }

        userList.add(user);

        return userList;


    }
    public int update(String name, String number, String email, String address, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.NAME, name);
        contentValues.put(DatabaseHelper.NUMBER, number);
        contentValues.put(DatabaseHelper.EMAIL, email);
        contentValues.put(DatabaseHelper.ADDRESS,address);
        contentValues.put(DatabaseHelper.PASSWORD, password);

        int i = database.update(DatabaseHelper.TABLE_NAME, contentValues, DatabaseHelper.NUMBER + " = " + number, null);
        return i;
    }

    public void delete(String number) {
        database.delete(DatabaseHelper.TABLE_NAME, DatabaseHelper.NUMBER + "=" + number, null);
    }
}
