package com.secson.agriapp.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.activities.MainActivity;
import com.secson.agriapp.R;

import java.util.ArrayList;

/**
 * Created by AD on 17/03/18.
 */

public class Drawer_Menu_Adapter extends BaseAdapter {
    Context c;
    Typeface thin;
    ArrayList<String> MenuItems;
    ArrayList<String> MenuCount;
    ArrayList<Integer> MenuIcon;
    String Position;

    public Drawer_Menu_Adapter(MainActivity c, ArrayList<String> menunames, ArrayList<Integer> menuicon, ArrayList<String> menucount) {
        this.c = c;
        this.MenuItems = menunames;
        this.MenuIcon = menuicon;
        this.MenuCount =  menucount;
        // thin = Typeface.createFromAsset(c.getAssets(), "fonts/thin.ttf");
    }
      /*  public void getPosition(String position){
            Position=position;
            notifyDataSetChanged();
        }
*/
    @Override
    public int getCount() {
        return MenuItems.size();
    }

    @Override
    public Object getItem(int position) {
        return MenuItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater;
        if (convertView == null) {
            inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.drawable_menu_row, parent, false);
        }
        LinearLayout llMenus=(LinearLayout) convertView.findViewById(R.id.llMenus);
        tt0142m t = (tt0142m) convertView.findViewById(R.id.menu_item);
        String s = MenuItems.get(position);
        tt0142m tvMenuCount = (tt0142m)convertView.findViewById(R.id.tvMenuCount);
       /* if(MenuCount.get(position) != null &&
                !MenuCount.get(position).equalsIgnoreCase("") )
        {   tvMenuCount.setVisibility(View.VISIBLE);
            tvMenuCount.setText(MenuCount.get(position));
        }else{
            tvMenuCount.setVisibility(View.INVISIBLE);
        }
*/
        ImageView menu_icon = (ImageView) convertView.findViewById(R.id.active_menu);
        menu_icon.setImageResource(MenuIcon.get(position));
        t.setText(s);
        t.setTypeface(thin);

        return convertView;
    }
}
