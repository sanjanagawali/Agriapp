package com.secson.agriapp.model;

public class User {

    private String name;
    private String number;
    private String email;
    private String address;
    private String password;


    public User(String name, String number, String email, String password) {
        this.name = name;
        this.number = number;
        this.email = email;
        this.address=address;
        this.password = password;
    }

    public User() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address){this.address =address;}

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getEmail() {
        return email;
    }
    public String getAddress() {
        return address;
    }
    public String getPassword() {
        return password;
    }
}
