package com.secson.agriapp.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.secson.agriapp.R;
import com.secson.agriapp.adapter.ProductAdapter;
import com.secson.agriapp.fonts.tt0144m;
import com.secson.agriapp.model.Product;

import java.util.ArrayList;



public class FertilizersFragment extends Fragment {

    private Context mContext;
    ListView listView;
    ArrayList<Product> productList;
    ProductAdapter adapter;
    String type;
    Toolbar toolbar;
    tt0144m tvToolbarTitle;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            type = bundle.getString("Type");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main_product, container, false);
        mContext = getActivity();
        listView = v.findViewById(R.id.productsLv);

        toolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        tvToolbarTitle =  toolbar.findViewById(R.id.ivLogo);

        productList = new ArrayList<>();
        // initLayout(v);
        getProducts();
        adapter = new ProductAdapter(productList, getActivity());
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        return v;
    }

    private void getProducts() {

        if(productList.size() > 0){
            productList.clear();
        }

        if (type.equalsIgnoreCase("fertilizer")) {
            tvToolbarTitle.setText("Fertilizers");
            productList.add(new Product(R.drawable.fertilizer1, "200", "Cosavet-DF"));
            productList.add(new Product(R.drawable.fertilizer2, "900", "RoundUp Herbi"));
            productList.add(new Product(R.drawable.fertilizer3, "500", "Glycel "));
            productList.add(new Product(R.drawable.fertilizer4, "400", "NUVAN"));
            productList.add(new Product(R.drawable.ultraction, "450", "Ultra action"));
            productList.add(new Product(R.drawable.alphacrop, "350", "Alpha Crop"));
            productList.add(new Product(R.drawable.biophorce, "400", "Bio-phorce"));
            productList.add(new Product(R.drawable.cheliatedfoliateapplication, "450", "Cheliated Foliate"));
            productList.add(new Product(R.drawable.fhumigel, "250", "Humi Gel"));
            productList.add(new Product(R.drawable.fkalasona, "560", "Kala Sona"));
            productList.add(new Product(R.drawable.fpendicile, "450", "Pendicile"));
            productList.add(new Product(R.drawable.frexton, "400", "Rextron"));
            productList.add(new Product(R.drawable.fsugarking, "340", "Sugarking"));
            productList.add(new Product(R.drawable.rhizobiummbf, "550", "Rhizobium MBF"));
            productList.add(new Product(R.drawable.richfieldnpk, "400", "Richfield NPK"));
            productList.add(new Product(R.drawable.richherbagreen, "450", "Rich HerbGreen"));

        }else if(type.equalsIgnoreCase("seeds")){
            tvToolbarTitle.setText("Seeds");
            productList.add(new Product(R.drawable.seed1, "400", "Super20 Wheat Seeds"));
            productList.add(new Product(R.drawable.seed3, "800", "Bombay super Guar seeds"));
            productList.add(new Product(R.drawable.nuziveedu, "500", "Nuziveedu cotton seeds"));
            productList.add(new Product(R.drawable.onion, "350", "Shrinivas Onion seeds"));
            productList.add(new Product(R.drawable.teaktree, "245", "Teaktree seeds"));
            productList.add(new Product(R.drawable.cosmoslady, "200", "cosmolady flower seeds"));
            productList.add(new Product(R.drawable.gardenbeans, "300", "Garden Bean seeds"));
            productList.add(new Product(R.drawable.lusterbean, "350", "Cluster Bean seeds"));
            productList.add(new Product(R.drawable.jowarseeds, "450", "super20 Jowar seeds"));
            productList.add(new Product(R.drawable.kemflowerseeds, "500", "kemflower seeds"));
            productList.add(new Product(R.drawable.vrlcottonseeds, "470", "VRL cotton seeds"));


        }else if(type.equalsIgnoreCase("tools")){
            tvToolbarTitle.setText("Tools");
            productList.add(new Product(R.drawable.tool1, "1000", "Chain Saw Machine"));
            productList.add(new Product(R.drawable.tool2, "1200", "Battery operated Sprayer"));
            productList.add(new Product(R.drawable.tool3, "1800", "Grains Separator"));
            productList.add(new Product(R.drawable.tiller, "2200", "Tiller"));
            productList.add(new Product(R.drawable.winno, "1500", "Winnowing Fan"));
            productList.add(new Product(R.drawable.mac1, "2200", "2 stroke crop-harvester"));
            productList.add(new Product(R.drawable.mac2, "2000", "brass htp sprayer"));
            productList.add(new Product(R.drawable.mac3, "1500", "Htp sprayer"));
            productList.add(new Product(R.drawable.mac4, "2200", "Tractor Sprayer"));
            productList.add(new Product(R.drawable.mac5, "2100", "Chain saw machine"));
            productList.add(new Product(R.drawable.mac6, "1100", "Seeding Machine"));
            productList.add(new Product(R.drawable.mac7, "800", "Trimmer line meter"));
            productList.add(new Product(R.drawable.mac8, "300", "Weedicide Nozzle Cap"));
            productList.add(new Product(R.drawable.mac9, "250", "Hedge shear-wooden"));
            productList.add(new Product(R.drawable.mac10, "200", "Khurpa"));
            productList.add(new Product(R.drawable.mac11, "200", "Trovel PVC"));



        }
    }
}
