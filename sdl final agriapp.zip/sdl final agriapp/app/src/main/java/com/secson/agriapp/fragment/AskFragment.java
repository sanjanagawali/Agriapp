package com.secson.agriapp.fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.secson.agriapp.R;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.fonts.tt0144m;

import static android.content.Context.TELEPHONY_SERVICE;

public class AskFragment extends Fragment {

    LinearLayout ll1,ll2,ll3;
    tt0142m numTxt1,numTxt2,numTxt3;
    int PERMISSION_ALL = 1;
    Toolbar toolbar;
    tt0144m tvToolbarTitle;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragmet_ask, container, false);

        ll1 = v.findViewById(R.id.callLL1);
        ll2 = v.findViewById(R.id.callLL2);
        ll3 = v.findViewById(R.id.callLL3);
        numTxt1 = v.findViewById(R.id.numTxt1);
        numTxt2 = v.findViewById(R.id.numTxt2);
        numTxt3 = v.findViewById(R.id.numTxt3);

        toolbar = (Toolbar) getActivity().findViewById(R.id.toolbar);
        tvToolbarTitle =  toolbar.findViewById(R.id.ivLogo);

        tvToolbarTitle.setText("Contact Us");

        String[] PERMISSIONS = {
                Manifest.permission.CALL_PHONE,
        };
        if (!hasPermissions(getActivity(), PERMISSIONS)) {
            ActivityCompat.requestPermissions(getActivity(), PERMISSIONS, PERMISSION_ALL);
        }


        ll1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                call(numTxt1.getText().toString().trim());
            }
        });

        ll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                call(numTxt2.getText().toString().trim());
            }
        });
        ll3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                call(numTxt3.getText().toString().trim());
            }
        });

        return v;
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= 23 && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
    public void call(String number){
        try {

            Uri callUri = Uri.parse("tel:" + number);
            Intent callIntent;
            if (isTelephonyEnabled(getActivity())) {
                callIntent = new Intent(Intent.ACTION_DIAL, callUri);
            } else {
                callIntent = new Intent(Intent.ACTION_VIEW, callUri);
            }
            startActivity(callIntent);

        } catch (Exception e) {
            Toast.makeText(getActivity(), "Something went wrong !", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isTelephonyEnabled(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(TELEPHONY_SERVICE);
        return telephonyManager != null && telephonyManager.getSimState() == TelephonyManager.SIM_STATE_READY;
    }
}
