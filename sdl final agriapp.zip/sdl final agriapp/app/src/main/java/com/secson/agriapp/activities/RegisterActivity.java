package com.secson.agriapp.activities;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.secson.agriapp.R;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.utils.DBManager;
import com.secson.agriapp.utils.DatabaseHelper;
import com.secson.agriapp.utils.ExportDatabase;

import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity {

    EditText edName, edContact, edEmail, etPass,edAddress;
    ImageView ivSave, ivBack;
    private DBManager dbManager;
    Cursor cursor;
    int PERMISSION_ALL = 1;

    ArrayList<String> nameList;
    ArrayList<String> numberList;
    ArrayList<String> addressList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        String[] PERMISSIONS = {
                Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        if (!hasPermissions(RegisterActivity.this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(RegisterActivity.this, PERMISSIONS, PERMISSION_ALL);
        }

        edName = findViewById(R.id.nameEditText);
        edContact = findViewById(R.id.contactEditText);
        edEmail = findViewById(R.id.emailEditText);
        edAddress=findViewById(R.id.addressEditText);
        etPass = findViewById(R.id.passEditText);

        ivBack = findViewById(R.id.backBtnUserProfile);
        ivSave = findViewById(R.id.ivSave);
        nameList = new ArrayList<>();
        numberList = new ArrayList<>();
        addressList= new ArrayList<>();



        dbManager = new DBManager(this);
        dbManager.open();


        cursor = dbManager.fetch();

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {

                    String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.NAME));
                    String number = cursor.getString(cursor.getColumnIndex(DatabaseHelper.NUMBER));
                    String address= cursor.getString(cursor.getColumnIndex(DatabaseHelper.ADDRESS));
                    nameList.add(name);
                    numberList.add(number);
                    addressList.add(address);
                    // do what ever you want here

                } while (cursor.moveToNext());
            }
        }
        cursor.close();

        ivSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edName.getText().toString().trim().length() == 0) {
                    Toast.makeText(RegisterActivity.this, "Please enter the name.", Toast.LENGTH_SHORT).show();
                } else if (edContact.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Please enter the Contact number.", Toast.LENGTH_SHORT).show();
                }else if (edContact.getText().toString().length()!=10) {
                    Toast.makeText(RegisterActivity.this, "contact number should be of 10 digits", Toast.LENGTH_SHORT).show();
                }else if (edEmail.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Please enter the Email.", Toast.LENGTH_SHORT).show();
                }else if (!edEmail.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+.[a-z]+")){
                    Toast.makeText(RegisterActivity.this, "Please enter valid Email.", Toast.LENGTH_SHORT).show();
                }else if (etPass.getText().toString().isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Password should not be empty.", Toast.LENGTH_SHORT).show();
                }else if (nameList.contains(edName.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "User already exist.", Toast.LENGTH_SHORT).show();
                }else if (numberList.contains(edContact.getText().toString())) {
                    Toast.makeText(RegisterActivity.this, "Number already exist.", Toast.LENGTH_SHORT).show();
                }else {
                    dbManager.insert(edName.getText().toString().trim(), edContact.getText().toString().trim(), edEmail.getText().toString().trim(),edAddress.getText().toString().trim(), etPass.getText().toString().trim());
                    Toast.makeText(RegisterActivity.this, "User registered successfully.", Toast.LENGTH_SHORT).show();



                    edName.setText("");
                    edContact.setText("");
                    edEmail.setText("");
                    edAddress.setText("");
                    etPass.setText("");

                }
            }
        });

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= 23 && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
}
