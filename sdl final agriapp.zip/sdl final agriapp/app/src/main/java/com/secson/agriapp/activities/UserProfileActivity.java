package com.secson.agriapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.secson.agriapp.R;
import com.secson.agriapp.constants.IConstatnts;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.model.User;
import com.secson.agriapp.utils.AgriappSharedPreference;
import com.secson.agriapp.utils.DBManager;
import com.secson.agriapp.utils.AgriappSharedPreference;

import java.util.ArrayList;

public class UserProfileActivity extends AppCompatActivity {

    private DBManager dbManager;
    ArrayList<User> usetList;
    ImageView ivBack;
    AgriappSharedPreference sp;
    tt0142m tvName,tvEmail,tvContact,tvAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        ivBack = findViewById(R.id.backBtnUserProfile);
        tvName = findViewById(R.id.nameEditText);
        tvContact = findViewById(R.id.contactEditText);
        tvEmail = findViewById(R.id.emailEditText);
        tvAddress=findViewById(R.id.addressEditText);

        dbManager = new DBManager(this);
        dbManager.open();
        sp = new AgriappSharedPreference();

        usetList = dbManager.getUserObject(sp.get(UserProfileActivity.this, IConstatnts.number));

        tvName.setText(usetList.get(0).getName());
        tvContact.setText(usetList.get(0).getNumber());
        tvEmail.setText(usetList.get(0).getEmail());
        tvAddress.setText(usetList.get(0).getAddress());

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
