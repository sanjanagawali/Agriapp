package com.secson.agriapp.model;

public class Product {

    private Integer img;
    private String rs;
    private String imgName;


    public Product(Integer img, String rs,String imgName) {
        this.img = img;
        this.rs = rs;
        this.imgName = imgName;
    }

    public String getImgName() {
        return imgName;
    }

    public Integer getImg() {
        return img;
    }

    public String getRs() {
        return rs;
    }
}
