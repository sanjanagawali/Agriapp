package com.secson.agriapp.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.secson.agriapp.R;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.fonts.tt0144m;
import com.secson.agriapp.fonts.tt0145m;
import com.secson.agriapp.fragment.PaymentFragment;
import com.secson.agriapp.model.Product;

import java.util.ArrayList;

public class ProductAdapter extends BaseAdapter {


    ArrayList<Product> proList;
    Context context;

    public ProductAdapter(ArrayList<Product> proList, Context context) {
        this.proList = proList;
        this.context = context;
    }


    private class ViewHolder {


        public ImageView ivProduct;
        public tt0144m tvTitle;
        public tt0142m tvTotalRs;
        public tt0145m btnBuyNow;

    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        ViewHolder holder = null;
        final int position;
        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.row_item_product, viewGroup, false);
            //holder = new ViewHolder();
            holder = new ViewHolder();

            holder.btnBuyNow = convertView.findViewById(R.id.btnBuyNow);
            holder.ivProduct = convertView.findViewById(R.id.imgPrduct);
            holder.tvTitle = convertView.findViewById(R.id.txtTitle);
            holder.tvTotalRs = convertView.findViewById(R.id.txtTotalRs);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        position = i;
        holder.tvTotalRs.setText(context.getResources().getString(R.string.Rs) + " " + proList.get(i).getRs());
        holder.tvTitle.setText(proList.get(i).getImgName());
        holder.ivProduct.setImageResource(proList.get(i).getImg());

        holder.btnBuyNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (context instanceof FragmentActivity) {
                    // We can get the fragment manager
                    FragmentTransaction tx = ((FragmentActivity) context).getSupportFragmentManager().beginTransaction();
                    PaymentFragment payment = new PaymentFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("rs", proList.get(position).getRs());
                    bundle.putString("title", proList.get(position).getImgName());
                    bundle.putInt("img", proList.get(position).getImg());
                    payment.setArguments(bundle);
                    tx.replace(R.id.frame_container, payment);
                    tx.addToBackStack(null);
                    tx.commit();
                }
            }
        });
        //holder.txtActualPrice.setText(context.getResources().getString(R.string.Rs) + " " + String.format("%.2f", totalPrice));

        return convertView;
    }

    @Override
    public int getCount() {
        return proList.size();
    }

    @Override
    public Object getItem(int i) {
        return proList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return proList.indexOf(getItem(i));
    }


}
