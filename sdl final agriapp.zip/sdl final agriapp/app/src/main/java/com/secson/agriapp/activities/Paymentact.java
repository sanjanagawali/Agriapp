package com.secson.agriapp.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.secson.agriapp.R;
import com.secson.agriapp.fonts.tt0142m;
import com.secson.agriapp.fonts.tt0144m;


public class Paymentact extends AppCompatActivity {



    Dialog dialog;
    tt0142m dialogBtnOk, dialogBtnCancel;
    Toolbar toolbar;
    tt0144m tvToolbarTitle;
    private Context mContext;
    private Button cashon;
    private Button paytm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paymentact);

        cashon=(Button) findViewById(R.id.button3);
        cashon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "your payment will done after delivery", Toast.LENGTH_LONG).show();
            }});
         paytm=(Button) findViewById(R.id.paytm);
         paytm.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Intent c=getPackageManager().getLaunchIntentForPackage("net.one97.paytm");
                 startActivity(c);
             }});


            }
}
